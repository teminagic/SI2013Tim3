-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2014 at 09:40 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

CREATE DATABASE IF NOT EXISTS `sql339553` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `sql339553`;

GRANT USAGE ON *.* TO 'SITim3'@'%' IDENTIFIED BY PASSWORD '*548A7A8D307389F7FCEF828B5593967F5AEA8A62';

GRANT ALL PRIVILEGES ON `sql339553`.* TO 'SITim3'@'%' WITH GRANT OPTION;

GRANT USAGE ON *.* TO 'SITim3'@'localhost' IDENTIFIED BY PASSWORD '*548A7A8D307389F7FCEF828B5593967F5AEA8A62';

GRANT ALL PRIVILEGES ON `sql339553`.* TO 'SITim3'@'localhost' WITH GRANT OPTION;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sql339553`
--

-- --------------------------------------------------------

--
-- Table structure for table `boja`
--

CREATE TABLE IF NOT EXISTS `boja` (
  `IDBoje` int(11) NOT NULL AUTO_INCREMENT,
  `Naziv` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IDBoje`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `boja`
--

INSERT INTO `boja` (`IDBoje`, `Naziv`) VALUES
(1, 'Crna'),
(2, 'Crvena'),
(3, 'Žuta'),
(4, 'Plava'),
(5, 'Zelena');

-- --------------------------------------------------------

--
-- Table structure for table `bojevozila`
--

CREATE TABLE IF NOT EXISTS `bojevozila` (
  `IDBojeVozila` int(11) NOT NULL AUTO_INCREMENT,
  `Nijansa` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Vrsta` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Boja` int(11) NOT NULL,
  `Tip` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Vozilo` int(11) NOT NULL,
  PRIMARY KEY (`IDBojeVozila`),
  KEY `fk_BojeVozila_Boje1_idx` (`Boja`),
  KEY `fk_BojeVozila_Vozila1_idx` (`Vozilo`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `bojevozila`
--

INSERT INTO `bojevozila` (`IDBojeVozila`, `Nijansa`, `Vrsta`, `Boja`, `Tip`, `Vozilo`) VALUES
(2, 'Standardna', 'Obična', 2, 'tip', 2),
(3, 'Standardna', 'Obična', 2, 'tip', 2),
(5, 'Standardna', 'Obična', 2, 'tip', 2),
(8, 'Standardna', 'Obična', 2, 'tip', 2),
(11, 'Standardna', 'Obična', 2, 'tip', 1);

-- --------------------------------------------------------

--
-- Table structure for table `logovi`
--

CREATE TABLE IF NOT EXISTS `logovi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `Datum` date NOT NULL,
  `Akcija` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `Description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `ID` (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=31 ;

--
-- Dumping data for table `logovi`
--

INSERT INTO `logovi` (`ID`, `Username`, `Datum`, `Akcija`, `Description`) VALUES
(1, 'admin', '2014-06-10', 'Prijava na sistem', 'Korisnik: admin'),
(2, 'admin', '2014-06-10', 'Kreiranje novog korisnika', 'Korisničko ime = boss'),
(3, 'admin', '2014-06-10', 'Kreiranje novog korisnika', 'Korisničko ime = salter'),
(4, 'admin', '2014-06-10', 'Odjava sa sistema', 'Korisnik: admin'),
(5, 'admin', '2014-06-10', 'Prijava na sistem', 'Korisnik: admin'),
(6, 'admin', '2014-06-10', 'Odjava sa sistema', 'Korisnik: admin'),
(7, 'admin', '2014-06-10', 'Prijava na sistem', 'Korisnik: admin'),
(8, 'admin', '2014-06-10', 'Odjava sa sistema', 'Korisnik: admin'),
(9, 'admin', '2014-06-10', 'Prijava na sistem', 'Korisnik: admin'),
(10, 'admin', '2014-06-10', 'Odjava sa sistema', 'Korisnik: admin'),
(11, 'admin', '2014-06-10', 'Prijava na sistem', 'Korisnik: admin'),
(12, 'admin', '2014-06-10', 'Odjava sa sistema', 'Korisnik: admin'),
(13, 'admin', '2014-06-10', 'Prijava na sistem', 'Korisnik: admin'),
(14, 'admin', '2014-06-10', 'Odjava sa sistema', 'Korisnik: admin'),
(15, 'salter', '2014-06-10', 'Prijava na sistem', 'Korisnik: salter'),
(16, 'salter', '2014-06-10', 'Prijava na sistem', 'Korisnik: salter'),
(17, 'salter', '2014-06-10', 'Prijava na sistem', 'Korisnik: salter'),
(18, 'salter', '2014-06-10', 'Prijava na sistem', 'Korisnik: salter'),
(19, 'admin', '2014-06-10', 'Prijava na sistem', 'Korisnik: admin'),
(20, 'admin', '2014-06-10', 'Odjava sa sistema', 'Korisnik: admin'),
(21, 'boss', '2014-06-10', 'Prijava na sistem', 'Korisnik: boss'),
(22, 'salter', '2014-06-10', 'Prijava na sistem', 'Korisnik: salter'),
(23, 'salter', '2014-06-10', 'Prijava na sistem', 'Korisnik: salter'),
(24, 'salter', '2014-06-10', 'Prijava na sistem', 'Korisnik: salter'),
(25, 'admin', '2014-06-10', 'Prijava na sistem', 'Korisnik: admin'),
(26, 'admin', '2014-06-10', 'Odjava sa sistema', 'Korisnik: admin'),
(27, 'admin', '2014-06-10', 'Prijava na sistem', 'Korisnik: admin'),
(28, 'admin', '2014-06-10', 'Kreiranje novog korisnika', 'Korisničko ime = salter'),
(29, 'admin', '2014-06-10', 'Odjava sa sistema', 'Korisnik: admin'),
(30, 'salter', '2014-06-10', 'Prijava na sistem', 'Korisnik: salter');

-- --------------------------------------------------------

--
-- Table structure for table `motor`
--

CREATE TABLE IF NOT EXISTS `motor` (
  `IDMotora` int(11) NOT NULL AUTO_INCREMENT,
  `ZapreminaMotora` int(11) NOT NULL,
  `MaksimalnaSnaga` int(11) NOT NULL,
  `VrstaGoriva` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `BrojMotora` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `VrstaMotora` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IDMotora`),
  UNIQUE KEY `BrojMotora` (`BrojMotora`),
  UNIQUE KEY `BrojMotora_4` (`BrojMotora`),
  UNIQUE KEY `BrojMotora_5` (`BrojMotora`),
  KEY `BrojMotora_2` (`BrojMotora`),
  KEY `BrojMotora_3` (`BrojMotora`),
  KEY `BrojMotora_6` (`BrojMotora`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `motor`
--

INSERT INTO `motor` (`IDMotora`, `ZapreminaMotora`, `MaksimalnaSnaga`, `VrstaGoriva`, `BrojMotora`, `VrstaMotora`) VALUES
(1, 60, 116, 'Benzin', '190T11', 'DIESEL'),
(2, 4, 248, 'Benzin', 'KT10DD', 'DIESEL'),
(12, 4, 4, 'Benzin', '342432dfrdf', 'DIESEL');

-- --------------------------------------------------------

--
-- Table structure for table `osoba`
--

CREATE TABLE IF NOT EXISTS `osoba` (
  `IDOsobe` int(11) NOT NULL AUTO_INCREMENT,
  `JMB_ID` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `Prezime` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Ime` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Prebivaliste` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `PravnoLice` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`IDOsobe`),
  UNIQUE KEY `JMB/ID_UNIQUE` (`JMB_ID`),
  UNIQUE KEY `IDOsobe` (`IDOsobe`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `osoba`
--

INSERT INTO `osoba` (`IDOsobe`, `JMB_ID`, `Prezime`, `Ime`, `Prebivaliste`, `PravnoLice`) VALUES
(1, '1909991398033', 'Dervić', 'Amra', 'Zagrebačka Travnik Travnik', 0),
(2, '167', 'Eminagić', 'Tarik', 'Uličica 54 Sarajevo Stari Grad', 1);

-- --------------------------------------------------------

--
-- Table structure for table `registracija`
--

CREATE TABLE IF NOT EXISTS `registracija` (
  `IDRegistracije` int(11) NOT NULL AUTO_INCREMENT,
  `RegistarskaOznaka` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Od` date NOT NULL,
  `Do` date DEFAULT NULL,
  `Vozilo` int(11) NOT NULL,
  `Osoba` int(11) NOT NULL,
  PRIMARY KEY (`IDRegistracije`),
  KEY `fk_Registracija_Vozila1_idx` (`Vozilo`),
  KEY `fk_Registracija_Osobe1_idx` (`Osoba`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `registracija`
--

INSERT INTO `registracija` (`IDRegistracije`, `RegistarskaOznaka`, `Od`, `Do`, `Vozilo`, `Osoba`) VALUES
(1, '567-A-543', '2014-06-05', '2015-06-05', 1, 1),
(2, '123-K-456', '2014-06-10', '2014-06-10', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `saobracajna`
--

CREATE TABLE IF NOT EXISTS `saobracajna` (
  `BrojDozvole` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `Vozilo` int(11) NOT NULL,
  `Korisnik` int(11) NOT NULL,
  PRIMARY KEY (`BrojDozvole`),
  KEY `fk_Korištenje_Vozila1_idx` (`Vozilo`),
  KEY `fk_Korištenje_Osobe1_idx` (`Korisnik`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `saobracajna`
--

INSERT INTO `saobracajna` (`BrojDozvole`, `Vozilo`, `Korisnik`) VALUES
('V2364', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tipuposlenika`
--

CREATE TABLE IF NOT EXISTS `tipuposlenika` (
  `IDTipaKorisnika` int(11) NOT NULL AUTO_INCREMENT,
  `Naziv` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IDTipaKorisnika`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tipuposlenika`
--

INSERT INTO `tipuposlenika` (`IDTipaKorisnika`, `Naziv`) VALUES
(1, 'Administrator'),
(2, 'Šalterski radnik'),
(3, 'Menadžer');

-- --------------------------------------------------------

--
-- Table structure for table `uposlenik`
--

CREATE TABLE IF NOT EXISTS `uposlenik` (
  `IDUposlenika` int(11) NOT NULL AUTO_INCREMENT,
  `Ime` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Prezime` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `KorisnickoIme` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Sifra` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `StatusKorisnika` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `TipKorisnika` int(11) NOT NULL,
  PRIMARY KEY (`IDUposlenika`),
  UNIQUE KEY `KorisničkoIme_UNIQUE` (`KorisnickoIme`),
  UNIQUE KEY `IDKorisnika` (`IDUposlenika`),
  KEY `fk_Korisnici_TipoviKorisnika_idx` (`TipKorisnika`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `uposlenik`
--

INSERT INTO `uposlenik` (`IDUposlenika`, `Ime`, `Prezime`, `KorisnickoIme`, `Sifra`, `StatusKorisnika`, `TipKorisnika`) VALUES
(1, 'Admin', 'Admin', 'admin', '2e33a9b0b06aa0a01ede70995674ee23', 'Aktivan', 1),
(2, 'Boss', 'Boss', 'boss', 'f3cf3961e7d169c9a89c88a3e0d5d80c', 'Aktivan', 3),
(12, 'Salter', 'Salter', 'salter', '19ada9f65ac7a2f9750b81d57b92309c', 'Aktivan', 2);

-- --------------------------------------------------------

--
-- Table structure for table `vlasnicka`
--

CREATE TABLE IF NOT EXISTS `vlasnicka` (
  `BrojDozvole` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `Vlasnik` int(11) NOT NULL,
  `Vozilo` int(11) NOT NULL,
  PRIMARY KEY (`BrojDozvole`),
  KEY `fk_Vlasništvo_Osobe1_idx` (`Vlasnik`),
  KEY `fk_Vlasništvo_Vozila1_idx` (`Vozilo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vlasnicka`
--

INSERT INTO `vlasnicka` (`BrojDozvole`, `Vlasnik`, `Vozilo`) VALUES
('22486D', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vozilo`
--

CREATE TABLE IF NOT EXISTS `vozilo` (
  `IDVozila` int(11) NOT NULL AUTO_INCREMENT,
  `Vrsta` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Marka` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Tip` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Model` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `BrojSasije` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `OblikKaroserije` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `GodinaProizvodnje` int(11) NOT NULL,
  `MaxTehnickaDozvoljenaMasa` int(11) NOT NULL,
  `MasaVozila` int(11) NOT NULL,
  `DopustenaNosivost` int(11) NOT NULL,
  `Motor` int(11) NOT NULL,
  `OdnosSnageIMase` decimal(5,2) DEFAULT NULL,
  `BrojMjestaZaSjedenje` int(11) NOT NULL,
  `BrojMjestaZaStajanje` int(11) NOT NULL,
  `BrojMjestaZaLezanje` int(11) NOT NULL,
  `EkoKarakteristikaVozila` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Katalizator` tinyint(1) NOT NULL,
  `DatumPregleda` date NOT NULL,
  `RegOznaka` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`IDVozila`),
  UNIQUE KEY `RegOznaka` (`RegOznaka`),
  UNIQUE KEY `RegOznaka_2` (`RegOznaka`),
  UNIQUE KEY `BrojSasije` (`BrojSasije`),
  KEY `fk_Vozila_Motori1_idx` (`Motor`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Dumping data for table `vozilo`
--

INSERT INTO `vozilo` (`IDVozila`, `Vrsta`, `Marka`, `Tip`, `Model`, `BrojSasije`, `OblikKaroserije`, `GodinaProizvodnje`, `MaxTehnickaDozvoljenaMasa`, `MasaVozila`, `DopustenaNosivost`, `Motor`, `OdnosSnageIMase`, `BrojMjestaZaSjedenje`, `BrojMjestaZaStajanje`, `BrojMjestaZaLezanje`, `EkoKarakteristikaVozila`, `Katalizator`, `DatumPregleda`, `RegOznaka`, `Status`) VALUES
(1, 'Putnički automobil', 'Toyota', 'SUV', 'rav4', 'WZZZ1JZXW000001', 'SUV', 2011, 2070, 1450, 620, 1, '0.08', 5, 0, 4, 'Euro 5', 1, '2014-06-01', '567-A-543', '1'),
(2, 'Putnički automobil', 'Mercedes', 'Sedan', 'C350', 'KJDUZ0001DD', 'limuzina', 2014, 1310, 810, 500, 2, '0.31', 5, 0, 4, 'Euro 5', 1, '2014-05-10', 'M78-K-542', '1');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bojevozila`
--
ALTER TABLE `bojevozila`
  ADD CONSTRAINT `fk_BojeVozila_Boje1` FOREIGN KEY (`Boja`) REFERENCES `boja` (`IDBoje`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_BojeVozila_Vozila1` FOREIGN KEY (`Vozilo`) REFERENCES `vozilo` (`IDVozila`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `registracija`
--
ALTER TABLE `registracija`
  ADD CONSTRAINT `fk_Registracija_Osobe1` FOREIGN KEY (`Osoba`) REFERENCES `osoba` (`IDOsobe`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Registracija_Vozila1` FOREIGN KEY (`Vozilo`) REFERENCES `vozilo` (`IDVozila`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `saobracajna`
--
ALTER TABLE `saobracajna`
  ADD CONSTRAINT `fk_Korištenje_Osobe1` FOREIGN KEY (`Korisnik`) REFERENCES `osoba` (`IDOsobe`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Korištenje_Vozila1` FOREIGN KEY (`Vozilo`) REFERENCES `vozilo` (`IDVozila`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `uposlenik`
--
ALTER TABLE `uposlenik`
  ADD CONSTRAINT `fk_Korisnici_TipoviKorisnika` FOREIGN KEY (`TipKorisnika`) REFERENCES `tipuposlenika` (`IDTipaKorisnika`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `vlasnicka`
--
ALTER TABLE `vlasnicka`
  ADD CONSTRAINT `fk_Vlasništvo_Osobe1` FOREIGN KEY (`Vlasnik`) REFERENCES `osoba` (`IDOsobe`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Vlasništvo_Vozila1` FOREIGN KEY (`Vozilo`) REFERENCES `vozilo` (`IDVozila`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `vozilo`
--
ALTER TABLE `vozilo`
  ADD CONSTRAINT `fk_Vozila_Motori1` FOREIGN KEY (`Motor`) REFERENCES `motor` (`IDMotora`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
